package proyectounidad2;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Gualo
 */
public class Tabla {
    String nombre;
    List <Atributo> atributos;

    public Tabla() {
        atributos = new ArrayList<Atributo>();
    }
 
}
