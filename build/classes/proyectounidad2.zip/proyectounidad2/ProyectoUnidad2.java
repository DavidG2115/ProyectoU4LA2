/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package proyectounidad2;

/**
 *
 * @author garcd
 */
public class ProyectoUnidad2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
       // Conexion conexion = new Conexion();
        //conexion.getConexion();
        
        GUI gui = new GUI();
        gui.setLocationRelativeTo(null);
        gui.setTitle("Unidad 2");
        gui.setVisible(true);
    }
    
}
