package proyectounidad2;
/**
 *
 * @author Gualo
 */
public class Atributo {
   String nombreAtributo;
    String tipoAtributo; 
    String tipoSQL;      
}
